package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

public class MyHealthDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "myhealth.db";
    private static final int DB_VERSION = 1;

    public MyHealthDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS user_profile (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "age INTEGER NOT NULL, " +
                "height_cm REAL NOT NULL, " +
                "weight_kg REAL NOT NULL, " +
                "gender TEXT NOT NULL, " +
                "activity_level TEXT NOT NULL, " +
                "recommended_calories REAL" +
                ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 如有需要可升級資料庫版本
        db.execSQL("DROP TABLE IF EXISTS user_profile");
        onCreate(db);
    }

    // 插入使用者資料
    public void insertUser(int age, double height, double weight, String gender, String activityLevel, double calories) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("age", age);
        values.put("height_cm", height);
        values.put("weight_kg", weight);
        values.put("gender", gender);
        values.put("activity_level", activityLevel);
        values.put("recommended_calories", calories);
        db.insert("user_profile", null, values);
    }
    public Cursor getLastUser() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM user_profile ORDER BY id DESC LIMIT 1", null);
    }

}
