package com.example.finalproject;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "food_clean.db";
    private static String DB_PATH = "";
    private final Context context;
    private SQLiteDatabase database;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.context = context;
        DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        copyDatabaseIfNeeded();
    }

    private void copyDatabaseIfNeeded() {
        File dbFile = new File(DB_PATH + DB_NAME);
        if (!dbFile.exists()) {
            getReadableDatabase(); // 建立空 DB 結構
            try {
                InputStream input = context.getAssets().open(DB_NAME);
                OutputStream output = new FileOutputStream(dbFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = input.read(buffer)) > 0) {
                    output.write(buffer, 0, length);
                }
                output.flush();
                output.close();
                input.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public String getNutritionByName(String keyword) {
        String result = "";
        database = getReadableDatabase();

        try {
            Cursor cursor = database.rawQuery(
                    "SELECT * FROM foods WHERE name LIKE ? OR alias LIKE ?",
                    new String[]{"%" + keyword + "%", "%" + keyword + "%"}
            );

            if (cursor.moveToFirst()) {
                result += "名稱: " + cursor.getString(cursor.getColumnIndexOrThrow("name")) + "\n";
                result += "俗名: " + cursor.getString(cursor.getColumnIndexOrThrow("alias")) + "\n";
                result += "熱量: " + cursor.getString(cursor.getColumnIndexOrThrow("calories_kcal")) + " kcal\n";
                result += "蛋白質: " + cursor.getString(cursor.getColumnIndexOrThrow("protein_g")) + " g\n";
                result += "脂肪: " + cursor.getString(cursor.getColumnIndexOrThrow("fat_g")) + " g\n";
                result += "飽和脂肪: " + cursor.getString(cursor.getColumnIndexOrThrow("saturated_fat_g")) + " g\n";
                result += "碳水化合物: " + cursor.getString(cursor.getColumnIndexOrThrow("carbohydrate_g")) + " g\n";
                result += "膳食纖維: " + cursor.getString(cursor.getColumnIndexOrThrow("fiber_g")) + " g\n";
                result += "總糖: " + cursor.getString(cursor.getColumnIndexOrThrow("sugar_g")) + " g\n";
                result += "鈉: " + cursor.getString(cursor.getColumnIndexOrThrow("sodium_mg")) + " mg\n";
                result += "鈣: " + cursor.getString(cursor.getColumnIndexOrThrow("calcium_mg")) + " mg\n";
                result += "鎂: " + cursor.getString(cursor.getColumnIndexOrThrow("magnesium_mg")) + " mg\n";
                result += "鐵: " + cursor.getString(cursor.getColumnIndexOrThrow("iron_mg")) + " mg\n";
                result += "鋅: " + cursor.getString(cursor.getColumnIndexOrThrow("zinc_mg")) + " mg\n";
                result += "反式脂肪: " + cursor.getString(cursor.getColumnIndexOrThrow("trans_fat_g")) + " g\n";
                result += "膽固醇: " + cursor.getString(cursor.getColumnIndexOrThrow("cholesterol_mg")) + " mg\n";
            } else {
                result = "查無資料";
            }

            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
            result = "查詢錯誤：" + e.getMessage();
        }

        return result;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 不需要建立資料表，從 assets 中複製即可
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 暫無升級邏輯
    }
}
