package com.example.finalproject;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText editAge, editHeight, editWeight;
    private Spinner spinnerGender, spinnerActivity;
    private TextView textRecommendedCalories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // 綁定元件
        editAge = findViewById(R.id.editAge);
        editHeight = findViewById(R.id.editHeight);
        editWeight = findViewById(R.id.editWeight);
        spinnerGender = findViewById(R.id.spinnerGender);
        spinnerActivity = findViewById(R.id.spinnerActivity);
        textRecommendedCalories = findViewById(R.id.textRecommendedCalories);
        Button btnSave = findViewById(R.id.btnSave);

        // 設定性別與活動量選單
        spinnerGender.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"男", "女"}));

        spinnerActivity.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"久坐", "輕量活動", "中等活動", "高度活動", "非常活躍"}));

        // 儲存按鈕點擊事件
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // 取得輸入資料
                    int age = Integer.parseInt(editAge.getText().toString());
                    double height = Double.parseDouble(editHeight.getText().toString());
                    double weight = Double.parseDouble(editWeight.getText().toString());
                    String gender = spinnerGender.getSelectedItem().toString();
                    String activity = spinnerActivity.getSelectedItem().toString();

                    // 計算熱量
                    double calories = calculateCalories(age, height, weight, gender, activity);

                    // 儲存進 SQLite
                    MyHealthDatabaseHelper dbHelper = new MyHealthDatabaseHelper(ProfileActivity.this);
                    dbHelper.insertUser(age, height, weight, gender, activity, calories);

                    // 顯示在畫面
                    textRecommendedCalories.setText("每日建議熱量：" + calories + " kcal");
                    Toast.makeText(ProfileActivity.this, "資料已儲存", Toast.LENGTH_SHORT).show();

                    // 顯示最後一筆資料
                    Cursor cursor = dbHelper.getLastUser();
                    if (cursor.moveToFirst()) {
                        int ageResult = cursor.getInt(cursor.getColumnIndexOrThrow("age"));
                        double heightResult = cursor.getDouble(cursor.getColumnIndexOrThrow("height_cm"));
                        double weightResult = cursor.getDouble(cursor.getColumnIndexOrThrow("weight_kg"));
                        String genderResult = cursor.getString(cursor.getColumnIndexOrThrow("gender"));
                        String activityResult = cursor.getString(cursor.getColumnIndexOrThrow("activity_level"));
                        double calResult = cursor.getDouble(cursor.getColumnIndexOrThrow("recommended_calories"));

                        Toast.makeText(ProfileActivity.this,
                                "已儲存：\n年齡: " + ageResult +
                                        "\n身高: " + heightResult +
                                        "\n體重: " + weightResult +
                                        "\n性別: " + genderResult +
                                        "\n活動量: " + activityResult +
                                        "\n熱量: " + calResult + " kcal",
                                Toast.LENGTH_LONG).show();
                    }
                    cursor.close();

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(ProfileActivity.this, "輸入錯誤，請確認格式是否正確", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // 計算每日建議熱量的函式
    private double calculateCalories(int age, double height, double weight, String gender, String activity) {
        double bmr;
        if (gender.equals("男")) {
            bmr = 66 + (13.7 * weight) + (5 * height) - (6.8 * age);
        } else {
            bmr = 655 + (9.6 * weight) + (1.8 * height) - (4.7 * age);
        }

        double activityFactor;
        switch (activity) {
            case "輕量活動":
                activityFactor = 1.375;
                break;
            case "中等活動":
                activityFactor = 1.55;
                break;
            case "高度活動":
                activityFactor = 1.725;
                break;
            case "非常活躍":
                activityFactor = 1.9;
                break;
            case "久坐":
            default:
                activityFactor = 1.2;
                break;
        }

        return Math.round(bmr * activityFactor * 10.0) / 10.0;
    }
}
